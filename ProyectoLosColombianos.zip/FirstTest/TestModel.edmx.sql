
-- --------------------------------------------------
-- Entity Designer DDL Script for SQL Server 2005, 2008, and Azure
-- --------------------------------------------------
-- Date Created: 02/12/2013 02:17:05
-- Generated from EDMX file: C:\Users\Erick\Documents\Sexto Semestre\Desarrollo Multicapas\Proyecto\FirstTest\FirstTest\TestModel.edmx
-- --------------------------------------------------

SET QUOTED_IDENTIFIER OFF;
GO
USE [LlamaClothingCo];
GO
IF SCHEMA_ID(N'dbo') IS NULL EXECUTE(N'CREATE SCHEMA [dbo]');
GO

-- --------------------------------------------------
-- Dropping existing FOREIGN KEY constraints
-- --------------------------------------------------

IF OBJECT_ID(N'[dbo].[FK_ClientTelephoneNumber]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[TelephoneNumbers] DROP CONSTRAINT [FK_ClientTelephoneNumber];
GO
IF OBJECT_ID(N'[dbo].[TelephoneNumbers]', 'U') IS NOT NULL
    DROP TABLE [dbo].[TelephoneNumbers];
GO

-- Creating table 'TelephoneNumbers'
CREATE TABLE [dbo].[TelephoneNumbers] (
    [TelephoneId] int  NOT NULL,
    [ClientId] int  NOT NULL,
    [Number] nvarchar(max)  NOT NULL
);
GO

-- Creating primary key on [TelephoneId], [ClientId] in table 'TelephoneNumbers'
ALTER TABLE [dbo].[TelephoneNumbers]
ADD CONSTRAINT [PK_TelephoneNumbers]
    PRIMARY KEY CLUSTERED ([TelephoneId], [ClientId] ASC);
GO


-- Creating foreign key on [ClientId] in table 'TelephoneNumbers'
ALTER TABLE [dbo].[TelephoneNumbers]
ADD CONSTRAINT [FK_ClientTelephoneNumber]
    FOREIGN KEY ([ClientId])
    REFERENCES [dbo].[Clients]
        ([ClientId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_ClientTelephoneNumber'
CREATE INDEX [IX_FK_ClientTelephoneNumber]
ON [dbo].[TelephoneNumbers]
    ([ClientId]);
GO

